module.exports = {
    name:"başvurukanal",
    code:`
    $setServerVar[başvurukanal;$mentionedChannels[1]]
    $title[❗️Başvuru Odası Başarı İle Ayarlandı❗️]
    $description[
        ✅Ayarlanan Oda: <#$mentionedChannels[1]>
    ]
    $footer[Ayarlayan Kişi $username[$authorID];$authorAvatar] $addTimestamp 
    $color[00FF00]
    $deleteIn[5s]
    $onlyPerms[managechannels;{title:❗️Üzgünüm Yetkin Yok❗️}{description: Bu Özelliği Kullanmak İçin Şu Yetkiye Ship Olmalısınız: **kanalları Yönet** }]
    $onlyIf[$message!=;{title:❗️Yanlış Kullanım❗️}{description:✅Doğru Kullanım: $getServerVar[prefix]başvurukanal #kanal}{color:00FF00}]
    `
  }