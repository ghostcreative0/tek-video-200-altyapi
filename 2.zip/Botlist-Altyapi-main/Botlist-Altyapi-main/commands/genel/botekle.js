module.exports = {
    name:"botekle",
    code:`
$setUserVar[botsahibi;$authorID;$message[1]]
$setUserVar[botprefix;$message[2];$message[1]]
$channelSendMessage[$channelID;{title:❗️Bot Ekleme Başvurun Başarı İle İşleme Alındı❗️}{description:✅Gerekli Değerlendirmeler Yapıldıktan Sonra Karar Verilicektir}{color:00FF00}]
$useChannel[$getServerVar[log2]]
$title[❗️Yeni Bir Bot Başvurusu❗️]
$description[$thumbnail[$userAvatar[$message[1]]]
    ✅Başvuran Kişi: $username#$discriminator
    ✅Başvuran  Kişi ID: $authorID
    ✅Başvuran  Kişi Etiket:  <@$authorID>
    ✅Bot ID: $message[1]
    ✅Bot Prefix: $message[2]
    ✅Bot İsmi: $username[$message[1]]$discriminator[$message[1]]
]
  $color[00FF00]
  $footer[Gerekli Değerlendirmeler Yapıldıktan Sonra Karar Verilicektir;$authorAvatar] $addTimestamp 
  $onlyIf[$isNumber[$message[1]]==true;{title:❗️Yanlış Kullanım❗️}{description:✅Doğru Kullanım: $getServerVar[prefix]botekle <botid> <prefix>}{color:00FF00}]
  $onlyIf[$isBot[$message[1]]==true;{title:❗️Girilen ID Bir Bot ID'si Değil❗️}{description:✅Lütfen Botunuzun ID sini Doğru Girin>}{color:00FF00}]
  $onlyIf[$message[2]!=;{title:❗️Yanlış Kullanım❗️}{description:✅Doğru Kullanım: $getServerVar[prefix]botekle <botid> <prefix>}{color:00FF00}]
  $onlyForChannels[$getServerVar[başvurukanal];{title:❗️Yanlış Oda Kullanımı❗️}{description:✅Lütfen Bot Başvurunuzu Şu Kanalda Yapın <#$getServerVar[başvurukanal]> }{color:00FF00}]
  $onlyIf[$getServerVar[log1]!=;{title:❗️Hata❗️}{description:✅Sistemlerden Herhangi Birisi Kapalı Lütfen Tüm Sistemleri Ayarladığınızdan Emin Olun}{color:00FF00}]
  $onlyIf[$getServerVar[yetkilirol]!=;{title:❗️Hata❗️}{description:✅Sistemlerden Herhangi Birisi Kapalı Lütfen Tüm Sistemleri Ayarladığınızdan Emin Olun}{color:00FF00}]
  $onlyIf[$getServerVar[başvurukanal]!=;{title:❗️Hata❗️}{description:✅Sistemlerden Herhangi Birisi Kapalı Lütfen Tüm Sistemleri Ayarladığınızdan Emin Olun}{color:00FF00}]
  $onlyIf[$getServerVar[log2]!=;{title:❗️Hata❗️}{description:✅Sistemlerden Herhangi Birisi Kapalı Lütfen Tüm Sistemleri Ayarladığınızdan Emin Olun}{color:00FF00}]
  $onlyIf[$getServerVar[log3]!=;{title:❗️Hata❗️}{description:✅Sistemlerden Herhangi Birisi Kapalı Lütfen Tüm Sistemleri Ayarladığınızdan Emin Olun}{color:00FF00}]
  $onlyIf[$getServerVar[botred;$message[1]]==hayır;{title:❗️Üzgünüm Botun Zaten Reddedilmiş❗️}{color:00FF00}]
  $onlyIf[$getServerVar[botonay;$message[1]]==hayır;{title:❗️Üzgünüm Botun Zaten Onaylanmış❗️}{color:00FF00}]
  `
  }