module.exports = {
    name:"botekle",
    code:`
    $useChannel[$getServerVar[log3]]
    $title[❗️Yeni Bir Bot Başvurusu❗️]
    $description[$thumbnail[$userAvatar[$message[1]]]
        ✅Başvuran Kişi: $username#$discriminator
        ✅Başvuran  Kişi ID: $authorID
        ✅Başvuran  Kişi Etiket:  <@$authorID>
        ✅Bot ID: $message[1]
        ✅Bot Prefix: $message[2]
        ✅Bot İsmi: $username[$message[1]]$discriminator[$message[1]]
        ✅[0 İzin'li Bot Davet Link]($getBotInvite)
        ✅[8 İzin'li Bot Davet Link]($getBotInvite[admin])
  ]
  $color[00FF00]
      $footer[❗️Lütfen Onay Veya Red İşlemini Geciktirmeyin❗️;$authorAvatar] $addTimestamp 
      $onlyIf[$isNumber[$message[1]]==true;]
      $onlyIf[$isBot[$message[1]]==true;]
      $onlyIf[$message[2]!=;]
      $onlyForChannels[$getServerVar[başvurukanal];]
      $onlyIf[$getServerVar[log1]!=;]
      $onlyIf[$getServerVar[yetkilirol]!=;]
      $onlyIf[$getServerVar[başvurukanal]!=;]
      $onlyIf[$getServerVar[log2]!=;]
      $onlyIf[$getServerVar[log3]!=;]
      $onlyIf[$getServerVar[botred;$message[1]]==hayır;]
      $onlyIf[$getServerVar[botonay;$message[1]]==hayır;]
  `
  }