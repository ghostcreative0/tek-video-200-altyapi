module.exports = {
    name: "ping",
    code: `
    $if[$ping>300]
    $title[İşte Pingim: $ping 🔴]
    $color[00FF00]
    $addTimestamp 
    $elseIf[$ping>200]
    $title[İşte Pingim: $ping 🟠]
    $color[ffa500]
    $addTimestamp 
    $endelseIf
    $elseIf[$ping>150]
    $title[İşte Pingim: $ping 🟡]
    $color[ffff00]
    $addTimestamp 
    $endelseIf
    $elseIf[$ping>100]
    $title[İşte Pingim: $ping 🟢]
    $color[00FF00]
    $addTimestamp 
    $endelseIf
    $endif
    `
}