module.exports = {
    name: "prefix",
    code: `
    $onlyIf[$message[1]!=;{title:❗️Yanlış Kullanım❗️}{description:✅Doğru Kullanım: $getServerVar[prefix]prefix-değiştir <yeni değer> }{color:00FF00}]
    $setServerVar[prefix;$message]
    $onlyPerms[admin;{title:❗️Üzgünüm Yetkin Yok❗️}{description: Bu Özelliği Kullanmak İçin Şu Yetkiye Ship Olmalısınız: **Yönetici** }]
    $title[❗️Prefix Başarı İle Değiştirildi❗️]
    $description[
        ✅Yeni Prefix: $noMentionMessage  
    ]
    $footer[Değiştiren Kişi $username[$authorID];$authorAvatar] $addTimestamp 
    $color[00FF00]
    `
}