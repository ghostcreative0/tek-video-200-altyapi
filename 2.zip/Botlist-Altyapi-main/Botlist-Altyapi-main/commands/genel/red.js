module.exports = {
    name:"reddet",
    code:`
    $setUserVar[botred;evet;$message[1]]
$channelSendMessage[$channelID;{title:❗️Bot Başarı İle Reddedildi❗️}{description:✅Bot Sahibine DM'den Bilgi Gönderildi}{color:00FF00}]
$useChannel[$getServerVar[log1]]
$title[❗️Bir Bot  Reddedildi❗️]
$description[$thumbnail[$userAvatar[$message[1]]]
    ✅Botun Sahibi: <@$message[1]>
    ✅Botun ismi:  $username[$message[2]]$discriminator[$message[2]]
    ✅Botun Prefixi: $getUserVar[botprefix;$message[2]]
    ✅Red Sebebi: $message[3] $message[4] $message[5] $message[6] $message[7] $message[8]
]
$color[RED]
$footer[Botun Yetersiz Görüldü;$authorAvatar] $addTimestamp 
  $onlyIf[$hasRole[$authorID;$getServerVar[yetkilirol]]!=false;;{title:❗️Üzgünüm Yetkin Yok❗️}{description: Bu Özelliği Kullanmak İçin Şu Role Sahip Olmalısınız: <#$getServerVar[yetkilirol]> }]
  $onlyIf[$isNumber[$message[1]]==true;{title:❗️Yanlış Kullanım❗️}{description:✅Doğru Kullanım: $getServerVar[prefix]reddet <üyeid <botid> <sebep>}{color:00FF00}]
  $onlyIf[$isNumber[$message[2]]==true;{title:❗️Yanlış Kullanım❗️}{description:✅Doğru Kullanım: $getServerVar[prefix]reddet <üyeid <botid> <sebep>}{color:00FF00}]
  $onlyIf[$getServerVar[log1]!=;{title:❗️Hata❗️}{description:✅Sistemlerden Herhangi Birisi Kapalı Lütfen Tüm Sistemleri Ayarladığınızdan Emin Olun}{color:00FF00}]
  $onlyIf[$getServerVar[yetkilirol]!=;{title:❗️Hata❗️}{description:✅Sistemlerden Herhangi Birisi Kapalı Lütfen Tüm Sistemleri Ayarladığınızdan Emin Olun}{color:00FF00}]
  $onlyIf[$getServerVar[başvurukanal]!=;{title:❗️Hata❗️}{description:✅Sistemlerden Herhangi Birisi Kapalı Lütfen Tüm Sistemleri Ayarladığınızdan Emin Olun}{color:00FF00}]
  $onlyIf[$getServerVar[log2]!=;{title:❗️Hata❗️}{description:✅Sistemlerden Herhangi Birisi Kapalı Lütfen Tüm Sistemleri Ayarladığınızdan Emin Olun}{color:00FF00}]
  $onlyIf[$getServerVar[log3]!=;{title:❗️Hata❗️}{description:✅Sistemlerden Herhangi Birisi Kapalı Lütfen Tüm Sistemleri Ayarladığınızdan Emin Olun}{color:00FF00}]
  $onlyIf[$isBot[$message[2]]==true;{title:❗️Girilen ID Bir Bot ID'si Değil❗️}{description:✅Lütfen Botun ID sini Doğru Girin>}{color:00FF00}]
  $onlyIf[$message[3]!=;{title:❗️Yanlış Kullanım❗️}{description:✅Doğru Kullanım: $getServerVar[prefix]reddet <üyeid> <botid> <sebep>}{color:00FF00}]
  $sendDM[$message[1];{title:❗️Botun Reddedildi❗️}{description:✅Daha Detaylı Bilgi İçin Sunucumuza Uğra}{color:00FF00}]
  $onlyIf[$getServerVar[botred;$message[1]]==hayır;{title:❗️Üzgünüm Bot Zaten Reddedilmiş❗️}{color:00FF00}]
  $onlyIf[$getServerVar[botonay;$message[1]]==hayır;{title:❗️Üzgünüm Bot Zaten Onaylanmış❗️}{color:00FF00}]
  `
  }