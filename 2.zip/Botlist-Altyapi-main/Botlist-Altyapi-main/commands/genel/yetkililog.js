module.exports = {
    name:"yetkililog",
    code:`
    $setServerVar[log3;$mentionedChannels[1]]
    $title[❗️Yetkili Log Odası Başarı İle Ayarlandı❗️]
    $description[
        ✅Ayarlanan Oda: <#$mentionedChannels[1]>
    ]
    $footer[Ayarlayan Kişi $username[$authorID];$authorAvatar] $addTimestamp 
    $color[00FF00]
    $deleteIn[5s]
    $onlyPerms[managechannels;{title:❗️Üzgünüm Yetkin Yok❗️}{description: Bu Özelliği Kullanmak İçin Şu Yetkiye Ship Olmalısınız: **kanalları Yönet** }]
    $onlyIf[$message!=;{title:❗️Yanlış Kullanım❗️}{description:✅Doğru Kullanım: $getServerVar[prefix]yetkililog #kanal}{color:00FF00}]
    `
  }