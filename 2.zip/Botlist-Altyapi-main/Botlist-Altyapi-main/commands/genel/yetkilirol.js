module.exports = {
    name:"yetkilirol",
    code:`
    $setServerVar[yetkilirol;$mentionedRoles[1]]
    $title[❗️Yetkili Rol Başarı İle Ayarlandı❗️]
    $description[
        ✅Ayarlanan Rol: <@$mentionedRoles[1]>
    ]
    $footer[Ayarlayan Kişi $username[$authorID];$authorAvatar] $addTimestamp 
    $color[00FF00]
    $deleteIn[5s]
    $onlyPerms[managechannels;{title:❗️Üzgünüm Yetkin Yok❗️}{description: Bu Özelliği Kullanmak İçin Şu Yetkiye Ship Olmalısınız: **kanalları Yönet** }]
    $onlyIf[$message!=;{title:❗️Yanlış Kullanım❗️}{description:✅Doğru Kullanım: $getServerVar[prefix]yetkilirol @rol}{color:00FF00}]
    `
  }