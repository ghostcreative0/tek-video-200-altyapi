const dbd = require("dbd.js")
const bot = new dbd.Bot({
token: "Token", 
prefix: "$getServerVar[prefix]",
mobile: false
})

bot.onMessage({
    guildOnly: false
})
const fs = require('fs')

const folders = fs.readdirSync("./commands/")

for (const files of folders) {
const folder = fs.readdirSync(`./commands/${files}/`).filter(file => file.endsWith(".js"))

for (const commands of folder) {
const command = require(`./commands/${files}/${commands}`) 
bot.command({
name: command.name,
aliases: command.aliases, // Here we make the bot read aliases correctly.
code: command.code
})
}
}
bot.variables({
    yetkilirol:"",
    log1:"",
    log2:"",
    başvurukanal:"",
    log3:"",
    botsahibi:"",
    prefix: "!",
    botprefix: "",
    botred: "hayır",
    botonay: "hayır"
  })
  //Log1: onay red
  //Log2: bot log
  //Log3: Yetkili Log
  bot.command({
    name: "eval",
    code: `
$eval[$message]
$onlyForIDs[776083082037821461;{title:❗️Üzgünüm Yetkin Yok❗️}{description: Bu Özelliği Kullanmak İçin Şu Yetkiye Sahip Olmalısınız: **Bot Sahibi** }{color:00FF00}]`
})
//Bear | Code Share Botlist Altyapı V1
bot.command({
  name: "yardım",
  code: `
  $title[🆘İşte Yardım Menüm🆘]
  $description[
      ✅Prefix: $getServerVar[prefix]
      ✅$getServerVar[prefix]başurukanal 
      ✅$getServerVar[prefix]başvurulog
      ✅$getServerVar[prefix]onayred
      ✅$getServerVar[prefix]yetkililog
      ✅$getServerVar[prefix]yetkilirol
      ✅$getServerVar[prefix]onay
      ✅$getServerVar[prefix]reddet
      ✅$getServerVar[prefix]başvur
      ✅$getServerVar[prefix]ping
      ✅$getServerVar[prefix]prefix
  ]
  $footer[İsteyen Kişi $username[$authorID];$authorAvatar] $addTimestamp 
  $color[00FF00]
  $deleteIn[20s]
  `
})