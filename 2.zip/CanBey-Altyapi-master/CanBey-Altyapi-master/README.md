**Bu Alt Yapı CANBEY Kanalına Aittir** 

``İzinsiz Paylaşımı Kesinlikle Yasaktır``

```Abone Olmayı Unutmayın```

[Youtube Kanalımız](https://www.youtube.com/channel/UCaCDrNU9_uUtCXV1OsSZM3g?view_as=subscriber)
