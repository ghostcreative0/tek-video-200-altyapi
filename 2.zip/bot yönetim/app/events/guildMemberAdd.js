module.exports = member => {
    let username = member.user.username;
    member.send('hoşgeldin.\nbot ekletmek istersen a!botekle botid prefix dblonaylı/onaysız yazman yeterli\nkodları görmek için a!js yazman yeterli!');
};
