                          Shydra Kod Paylaşım
 Discord Botumuz: <https://is.gd/NisLKa/>
 
 Discord Botumuzun Sitesi: <https://shydra.glitch.me//>
 
 Discord Botumuzun Destek Sunucusu: <https://discordapp.com/invite/EDHTEQN/>
 
 Discord Kod Paylaşım Sunucumuz: <https://discord.gg/Qx4XH6T/>
 

                            Açıklama

  Telif Hakkı Vardır Felan Zımbırtılar Kesinlikle Yalandır. Diğer Sunucularda Böyle Saçma Şeyler Gördüm Dilediğiniz Gibi Çalabilirsiniz.