Bot Altyapı Projesine Hoşgeldin!
=================
 Bu Dosya Tamamen `zMorcy'ye Aittir`. Bot Altyapısını Sizlerin Kullanması İçin Verdik Gerekli Modüller Yüklüdür..!

[Resmi Discord Sunucumuz](https://discord.gg/kQJQJgr)

[Resmi Youtube Kanalımız](https://www.youtube.com)


-------------------

`İyi Kodlamalar ay iyi düzeltmeler`

