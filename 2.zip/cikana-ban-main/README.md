# cikana-ban
Sunucunuzdan çıkan insanları yan sunuculardan banlar.
