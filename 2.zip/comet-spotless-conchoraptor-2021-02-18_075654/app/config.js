const config = {
    "ownerID": "İD", //kendi IDınızı yazınız
    "admins": ["İD"],
    "support": ["İD"],
    "token": "TOKEN", //botunuzun tokenini yazınız
    "dashboard" : {
      "oauthSecret": "", //botunuzun secretini yazınız
      "callbackURL": `https://vortex-altyaps.glitch.me/callback`, //site URLnizi yazınız /callback kısmını silmeyiniz!
      "sessionSecret": "super-secret-session-thing", //kalsın
      "domain": "https://vortex-altyaps.glitch.me", //site URLnizi yazınız!
          "port": process.env.PORT
    }
  };
  
  module.exports = config;

// PROJEYİ GİZLİYE ALMAYI UNUTMA
// PROJEYİ GİZLİYE ALMAYI UNUTMA
// PROJEYİ GİZLİYE ALMAYI UNUTMA
// PROJEYİ GİZLİYE ALMAYI UNUTMA
// PROJEYİ GİZLİYE ALMAYI UNUTMA
// PROJEYİ GİZLİYE ALMAYI UNUTMA
// PROJEYİ GİZLİYE ALMAYI UNUTMA
// PROJEYİ GİZLİYE ALMAYI UNUTMA
// PROJEYİ GİZLİYE ALMAYI UNUTMA
// PROJEYİ GİZLİYE ALMAYI UNUTMA
// PROJEYİ GİZLİYE ALMAYI UNUTMA
// PROJEYİ GİZLİYE ALMAYI UNUTMA
// PROJEYİ GİZLİYE ALMAYI UNUTMA
// PROJEYİ GİZLİYE ALMAYI UNUTMA
// PROJEYİ GİZLİYE ALMAYI UNUTMA
// PROJEYİ GİZLİYE ALMAYI UNUTMA
// PROJEYİ GİZLİYE ALMAYI UNUTMA
// PROJEYİ GİZLİYE ALMAYI UNUTMA

//GİZLYİE ALMASANIZ SUNUCUNUZ PATLIYABİLİR
