# [Universal Code (Nepenthe)](https://discord.gg/WbMUB2k) kod paylaşım sunucusu açık kaynak kodları
- Kodlar tamamen [barbarbar338](https://discordapp.com/users/331846231514939392), [Yashinu](https://discordapp.com/users/460813657811582986) ve [Alosha](https://discordapp.com/users/558016135052787773) tarafından [Code Academy Discord sunucusu](https://discord.gg/mXNUeBD) için hazırlanmıştır.

[HATALAR LOZ'BEY TARAFINCA GIDERILMISTIR](https://www.instagram.com/ynsemrearpacii) 
