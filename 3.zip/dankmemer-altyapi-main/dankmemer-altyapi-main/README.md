♣ **bot çalışmıyor ama içindeki komutları kullanabilirsiniz!**
♣ **yani ben çalıştıramadım ama siz belki açabilirsiniz!**
