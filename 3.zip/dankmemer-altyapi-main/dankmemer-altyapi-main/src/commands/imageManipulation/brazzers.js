const { GenericImageCommand } = require('../../models/');

module.exports = new GenericImageCommand({
  triggers: ['brazzers'],
  description: 'Someone have a spicy profile pic? See a hot new picture of Trump online? Add the Brazzers logo with this command to make it spicy hot.'
});
