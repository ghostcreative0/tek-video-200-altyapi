const { GenericImageCommand } = require('../../models/');

module.exports = new GenericImageCommand({
  triggers: ['dab'],
  description: 'Dab on the haters'
});
