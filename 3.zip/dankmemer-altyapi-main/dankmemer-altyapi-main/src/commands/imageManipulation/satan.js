const { GenericImageCommand } = require('../../models/');

module.exports = new GenericImageCommand({
  triggers: ['satan', 'lucifer', 'devil'],
  description: 'You are satan ok'
});
