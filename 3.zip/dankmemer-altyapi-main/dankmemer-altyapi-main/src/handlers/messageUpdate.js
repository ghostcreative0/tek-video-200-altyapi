exports.handle = function () {
  this.ddog.increment('global.messageEdits');
};
