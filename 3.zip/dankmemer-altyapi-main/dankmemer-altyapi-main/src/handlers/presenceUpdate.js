exports.handle = function () {
  this.ddog.increment('global.presenceUpdates');
};
