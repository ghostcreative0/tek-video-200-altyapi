# 🇹🇷 Türk Bot 🇹🇷 Altyapı

# Altyapı `Akardiyan` a aittir

Bot Altyapı Projesine Hoşgeldin!
=================
 Bu Dosya Tamamen `'Akardiyan'e Aittir`. Bot Altyapısını Video'da Belirtildiği Gibi Kullanmanız İçin Verdik Emeğe Saygı İzinsiz Paylaşmayalım

 Gerekli Modüller Yüklüdür Eğer Siz Dilerseniz Başka Modüller de Yükleyebilirsiniz

[Discord Sunucumuz](https://discord.gg/YjtGp8cAS3)

[Youtube Kanalımız](https://www.youtube.com/channel/UCefQXJPxd3YxXea-W-hq5RQ)



-------------------
