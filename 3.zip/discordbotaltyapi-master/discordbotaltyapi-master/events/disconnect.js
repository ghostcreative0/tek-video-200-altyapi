module.exports = client => {
  console.log(`Bağlantı Koptu Yeniden Bağlanılıyor ${new Date()}`);
};
