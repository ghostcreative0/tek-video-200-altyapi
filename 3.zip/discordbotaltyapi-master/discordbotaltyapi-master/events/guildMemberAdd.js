module.exports = member => {
  console.log((member));
};
