Herkese Selam Ben:
ByMySpanık#0514 bu altyapı hem kendi sunucumda olan FroLenk Eğlence Bot Sunucusu hemde Anticode kod paylaşım sunucusu için yapılmış ve paylaşılmıştır
Şurda burda ben yaptım falan demeyin! çalmayın veya invite, para veya her hangibir ticaretle verilmez alınmaz!
-- -- --
Copyright © FroLenk-2021

Tüm Hakları Saklıdır ve Paylaşılmaz.

-- -- --

FroLenk Eğlence bot sunucusu= 
https://discord.gg/AzE23M5a5K

Anticode Development= 
https://discord.gg/mAcYU4KRfH

FroLenk Bot Davet Link= 
https://discord.com/api/oauth2/authorize?client_id=791932586250207232&permissions=8&scope=bot

-- -- --
**Kurulum**

env kırmına token yazıyoruz sonra FroLenk.js ve ayarlar.json doldurmanız gerek yerleri doldurunuz

Talep açma: belirlediğin kanala mesaj yazıldığı an mesaj siler ve özel bir kanal oluşturur sadece destek rolündekiler ve mesaj yazan kişi için 
  mesaj yazan orda bulunan emojiye basması gerek ve o zaman yetkililerle iletişime geçmiş sayılır.