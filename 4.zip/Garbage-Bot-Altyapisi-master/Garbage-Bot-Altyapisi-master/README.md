Kurulum - Windows

1 Adım: Node.JS programını kurun. (nodejs.org)
2 Adım: Projeyi bilgisayarınıza indirin.
3 Adım: Proje dosyalarını açın, proje dosyalarının olduğu klasörde komut penceresini açın (Ctrl+Sağ tık > komut penceresini burada aç)
4 Adım: Açılan komut penceresine npm install komutunu yazın ve modüllerin yüklenmesini bekleyin.
5 Adım: Ayarlar.json dosyasını açıp ayarlarınızı yapın.
6 Adım: Modüller yüklendikten sonra, komut penceresine node bot.js komutunu yazın ve botu çalıştırın. Botun altyapısı için kullandığım kaynak: https://github.com/AnIdiotsGuide/Tutorial-Bot