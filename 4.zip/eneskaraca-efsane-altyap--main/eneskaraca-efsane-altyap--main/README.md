Tamamiyle Astral Code Yetkilisi Beta#0868'e aittir hata olursa ulaşın bana.
