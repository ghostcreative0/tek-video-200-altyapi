# **Bilgilendirme**

> **`Hepinize Merhaba Arkadaşlar Bu Videoda Yeni Hazırladığımız Ünlü Public Sunucularının Kayıt Sistemlerini Tanıttım,İyi Seyiler Diliyorum Tekrardan. Bu Tarz Videoların Devamı İçin Videoya Like ve Yorum Atmayı Unutmayın`**

> [Videoya Gitmek İçin Tıkla](https://youtu.be/QyKThdAtawc) 

> [Discord Sunucusuna Katılmak İçin Tıkla](https://discord.gg/axjXvA9cCa)

> 💳▸ Desteklemek için;

> 💳▸ İninal barkod : 4 092180334644

> 📊▸ Sponsorluk ve reklam için;

> 📊▸ E-Posta adresi : kantasmehmetcan12@gmail.com

> 🎮▸ Discord Nick : Kobs#0001
