**Arkadaşlar Selamlar Tekrardan,Bu V12 Uyumlu Botu Yaptık Ama,Rica Ediyorum Paylaşmayın Sizler İçin Bir Uğraş Gösteriyorum Burada,He Paylaşıcakmısınız İzin Alın Be Gardaşım,He Paylaşıyorsanızda Verdiğiniz Kişi Bi Zahmet Sunucuya Katılsın,Bizde İşimizi Görelim**


``Youtube``

**<https://www.youtube.com/ogünsertkobs>**

``Discord``

**<https://discord.gg/NP7Ar2j>**