❤️ Mindless Code Moderasyon Altyapısı

❤️ Code ve Public sunucumuz =https://discord.gg/7hM3z3m3pR 

❤️ Altyapı lisanslıdır izinsiz çalıp paylaşmayın

❤️ Mindless Code & Ege ❤️