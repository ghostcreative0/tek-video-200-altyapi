# Bayrak#1337 ve ネ ƛntikor & Morfin Bi Sƛkinleş#1881'e Aittir!

https://cdn.discordapp.com/attachments/823894794316021811/835234482242977862/unknown.png Açın bi XD
