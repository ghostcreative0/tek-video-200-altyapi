Wizard Bot Altyapı Projesine Hoşgeldin!
=================
 Bu Dosya Tamamen `BekBerKa'ya Aittir`. Bot Altyapısını Sizlerin Kullanması İçin Verdim Gerekli Modüller Yüklüdür..!

[Botumuzun Destek Sunucusuna Gelmek İçin Tıkla!](https://discord.gg/yKg2xsM)

[Botumuzu Sunucuna Eklemek İçin Tıkla!](https://goo.gl/XtNj6f)

[Botumuzun WEB Sitesine Gitmek İçin Tıkla!](https://wizard-bot-resmi.glitch.me/)

[Botumuza Oy Vermek için Tıkla!](https://discordbots.org/bot/530026473143271424)

-------------------

`İyi Kodlamalar`

